# PS5 Restock Telegram Bot

This project provides the Telegram notification layer for a PS5 stock-alert system.

## Important
Amazon India and Flipkart prohibit automated scraping/monitoring of their websites under their published terms. This project therefore does **not** scrape or bypass either site. Connect it only to an authorized API/feed or a monitoring service that has permission to provide the stock data.

## Setup

1. Create your bot with @BotFather.
2. Generate a fresh token if the old token was exposed.
3. Copy `.env.example` to `.env`.
4. Put your new token into `TELEGRAM_BOT_TOKEN`.
5. Leave `TELEGRAM_CHAT_ID` empty initially.
6. Run:

   pip install -r requirements.txt
   python bot.py

7. Open your bot in Telegram and send `/start`.
8. The bot will reply and the Telegram layer is confirmed.

## Authorized stock source

Send a POST request to:

`/stock-alert`

with header:

`X-Alert-Secret: YOUR_ALERT_SECRET`

and JSON such as:

{
  "product_key": "ps5_slim_disc_amazon",
  "store": "Amazon",
  "name": "PlayStation 5 Slim Disc Edition",
  "price": "₹49,990",
  "url": "https://example.com/product",
  "available": true,
  "deliverable_pin": "141001",
  "delivery": "Tomorrow"
}

The bot sends an alert only when the effective state changes from unavailable to available and the delivery PIN is 141001.

## Commands

/start
/status
/check
/help
